# the-borrowed-nuke-bot
This is a nuke bot from axes thanks to him &lt;3 love to him and credit to him
So what you will do is go to replit.com make a python and download both the files the config and the main and upload the files onto the replit 
and you can change the code if you want but add credit ;) 
if you need help dm (っ◔◡◔)っ ♥ Psycho101rl ♥#5136 or dm Dexzy✞#0001
also if you need help with setting your bot up 24/7 i will help you just dm me (っ◔◡◔)っ ♥ Psycho101rl ♥#5136 i also have another version V2
it will cost 10 invites for the V2 or we can make a deal together if there is something wrong with the bot dm me (っ◔◡◔)っ ♥ Psycho101rl ♥#5136
